<?php

include_once BRIDGE_CORE_SHORTCODES_PATH.'/advanced-call-to-action/functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/advanced-call-to-action/advanced-call-to-action.php';
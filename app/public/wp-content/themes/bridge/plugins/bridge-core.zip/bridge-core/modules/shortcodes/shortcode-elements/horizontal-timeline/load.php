<?php

include_once BRIDGE_CORE_SHORTCODES_PATH.'/horizontal-timeline/functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/horizontal-timeline/horizontal-timeline.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/horizontal-timeline/horizontal-timeline-item.php';